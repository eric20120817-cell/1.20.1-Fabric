local l = (bl and 1) or -1

if I:isOf(item, Items:get("minecraft:totem_of_undying")) then

M:moveX(matrices, -0.125*l)
M:moveY(matrices, 0.125)
M:rotateX(matrices, -10)
M:rotateY(matrices, 55 * l)
I:setTranslate(item, true)

particleManager:addParticle(
    particles,
    false,
    0.5 * l, 0.1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2.5,
    Texture:of("minecraft", "textures/particle/glow.png"),
    "ITEM",
    hand,
    "SPAWN",
    "ADDITIVE",
    0,
    200
)

end